
# Create your tests here.
import views
print(views.val1)